#include "enemies.h"

void Enemy::draw(){
    DrawCircle(x, y, 10, BLACK);
}